-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2016-01-22 14:19:14.055




-- tables
-- Table: HoaDon
CREATE TABLE HoaDon (
    Ma_HD varchar(10)  NOT NULL,
    Ma_KH varchar(10)  NOT NULL,
    NgayMua date  NOT NULL,
    Ten_KH varchar(30)  NOT NULL,
    DiaChi varchar(50)  NOT NULL,
    KhachHang_Ma_KH varchar(10)  NOT NULL,
    CONSTRAINT HoaDon_pk PRIMARY KEY  (Ma_HD)
)
;





-- Table: HoaDonChiTiet
CREATE TABLE HoaDonChiTiet (
    Ma_HD varchar(10)  NOT NULL,
    Ma_SP varchar(10)  NOT NULL,
    DonGia money  NOT NULL,
    SoLuong int  NOT NULL,
    ThanhTien money  NOT NULL,
    HoaDon_Ma_HD varchar(10)  NOT NULL,
    SanPham_Ma_SP varchar(10)  NOT NULL,
    CONSTRAINT HoaDonChiTiet_pk PRIMARY KEY  (Ma_HD)
)
;





-- Table: KhachHang
CREATE TABLE KhachHang (
    Ma_KH varchar(10)  NOT NULL,
    Ten_KH varchar(30)  NOT NULL,
    GioiTinh varchar(10)  NOT NULL,
    DiaChi varchar(50)  NOT NULL,
    SDT int  NOT NULL,
    CONSTRAINT KhachHang_pk PRIMARY KEY  (Ma_KH)
)
;





-- Table: LoaiSanPham
CREATE TABLE LoaiSanPham (
    Ma_Loai varchar(10)  NOT NULL,
    TenLoai_SP varchar(20)  NOT NULL,
    CONSTRAINT LoaiSanPham_pk PRIMARY KEY  (Ma_Loai)
)
;





-- Table: SanPham
CREATE TABLE SanPham (
    Ma_SP varchar(10)  NOT NULL,
    Ten_SP varchar(20)  NOT NULL,
    Ma_Loai varchar(10)  NOT NULL,
    SoLuong int  NOT NULL,
    LoaiSanPham_Ma_Loai varchar(10)  NOT NULL,
    CONSTRAINT SanPham_pk PRIMARY KEY  (Ma_SP)
)
;









-- foreign keys
-- Reference:  HoaDonChiTiet_HoaDon (table: HoaDonChiTiet)

ALTER TABLE HoaDonChiTiet ADD CONSTRAINT HoaDonChiTiet_HoaDon 
    FOREIGN KEY (HoaDon_Ma_HD)
    REFERENCES HoaDon (Ma_HD)
;

-- Reference:  HoaDonChiTiet_SanPham (table: HoaDonChiTiet)

ALTER TABLE HoaDonChiTiet ADD CONSTRAINT HoaDonChiTiet_SanPham 
    FOREIGN KEY (SanPham_Ma_SP)
    REFERENCES SanPham (Ma_SP)
;

-- Reference:  HoaDon_KhachHang (table: HoaDon)

ALTER TABLE HoaDon ADD CONSTRAINT HoaDon_KhachHang 
    FOREIGN KEY (KhachHang_Ma_KH)
    REFERENCES KhachHang (Ma_KH)
;

-- Reference:  SanPham_LoaiSanPham (table: SanPham)

ALTER TABLE SanPham ADD CONSTRAINT SanPham_LoaiSanPham 
    FOREIGN KEY (LoaiSanPham_Ma_Loai)
    REFERENCES LoaiSanPham (Ma_Loai)
;





-- End of file.

